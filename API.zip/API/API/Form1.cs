﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace API
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        /// /////Declaring Structure

        //Struct to retrive system info

        [StructLayout(LayoutKind.Sequential)]
        public struct SYSTEM_INFO
        {
            public uint dwOemId;
            public uint dwPageSize;
            public uint lpMinimumApplicationAddress;
            public uint lpMaximumApplicationAddress;
            public uint dwActiveProcessorMask;
            public uint dwNumberOfProcessors;
            public uint dwProcessorType;
            public uint dwAllocationGranularity;
            public uint dwProcessorLevel;
            public uint dwProcessorRevision;
        }


        //struct to retrive memory status

        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORYSTATUS
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public uint dwTotalPhys;
            public uint dwAvailPhys;
            public uint dwTotalPageFile;
            public uint dwAvailPageFile;
            public uint dwTotalVirtual;
            public uint dwAvailVirtual;
        }


           //Declare the API function:

            [DllImport("kernel32")]
            static extern void GetSystemInfo(ref SYSTEM_INFO pSI);

            //To get Memory status
            [DllImport("kernel32")]
            static extern void GlobalMemoryStatus(ref MEMORYSTATUS buf);


        private void button1_Click(object sender, EventArgs e)
        {
            try
	           {
                   listBox1.Items.Clear();

		SYSTEM_INFO pSI = new SYSTEM_INFO();
		GetSystemInfo(ref pSI);

        listBox1.Items.Add("Active Processor Mask :		" + pSI.dwActiveProcessorMask.ToString());
        listBox1.Items.Add("Allocation Granularity :		" + pSI.dwAllocationGranularity.ToString());
        listBox1.Items.Add("Number Of Processors :		" + pSI.dwNumberOfProcessors.ToString());
        listBox1.Items.Add("OEM ID :				" + pSI.dwOemId.ToString());
        listBox1.Items.Add("Page Size :			" + pSI.dwPageSize.ToString());
        listBox1.Items.Add("Processor Level Value :		" + pSI.dwProcessorLevel.ToString());
        listBox1.Items.Add("Processor Revision :		" + pSI.dwProcessorRevision.ToString());
        listBox1.Items.Add("Maximum Application Address :	" + pSI.lpMaximumApplicationAddress.ToString());
        listBox1.Items.Add("Minimum Application Address :	" + pSI.lpMinimumApplicationAddress.ToString());
        //listBox1.Items.Add(

               }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }


          }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.Clear();

                MEMORYSTATUS memSt = new MEMORYSTATUS();
                GlobalMemoryStatus(ref memSt);

                listBox1.Items.Add("Available Page File :		" + (memSt.dwAvailPageFile / 1024).ToString());
                listBox1.Items.Add("Available Physical Memory :		" + (memSt.dwAvailPhys/1024).ToString()); 
                listBox1.Items.Add("Available Virtual Memory :		" + (memSt.dwAvailVirtual/1024).ToString ());
                listBox1.Items.Add("Size of structur :			" + memSt.dwLength.ToString()); 
                listBox1.Items.Add("Memory In Use :			" + memSt.dwMemoryLoad.ToString());
                listBox1.Items.Add("Total Page Size :			" + (memSt.dwTotalPageFile / 1024).ToString());
                listBox1.Items.Add("Total Physical Memory :		" + (memSt.dwTotalPhys/1024).ToString());
                listBox1.Items.Add("Total Virtual Memory :		" + (memSt.dwTotalVirtual / 1024).ToString());




            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }


    }
}
